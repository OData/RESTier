﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Microsoft.Restier.Tests.Shared
{

    /// <summary>
    /// 
    /// </summary>
    public class RestierTestBase
    {

        /// <summary>
        /// 
        /// </summary>
        public TestContext TestContext { get; set; }

    }

}