﻿namespace Microsoft.Restier.Tests.Shared
{
    internal class Customer
    {
        public short Id { get; set; }
    }
}
