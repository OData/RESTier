﻿namespace Microsoft.Restier.Tests.Shared
{
    internal class Address
    {
        public int Zip { get; set; }
    }
}
