﻿namespace Microsoft.Restier.Tests.Shared
{
    internal class Store
    {
        public long Id { get; set; }
    }
}
