﻿using System;
using Microsoft.Restier.Core;

namespace Microsoft.Restier.Tests.Shared
{

    internal class StoreApi : ApiBase
    {
        public StoreApi(IServiceProvider serviceProvider) : base(serviceProvider)
        {
        }

    }

}